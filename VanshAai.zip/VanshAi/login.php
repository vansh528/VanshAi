<?php
session_start();
$data = json_decode(file_get_contents("php://input"), true);
$creds = json_decode(file_get_contents("credentials.json"), true);

if ($data["username"] === $creds["username"] && $data["password"] === $creds["password"]) {
  $_SESSION["admin"] = true;
  echo json_encode(["success" => true]);
} else {
  echo json_encode(["success" => false, "message" => "Invalid login"]);
}
?>