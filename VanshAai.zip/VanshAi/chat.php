<?php
include "config.php";
header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);
$message = $data['message'] ?? '';

$toneData = json_decode(file_get_contents("Admin/settings.json"), true);
$tone = $toneData["tone"] ?? "friendly";

$payload = [
  "model" => "gpt-3.5-turbo",
  "messages" => [["role" => "user", "content" => "Reply in a $tone tone: " . $message]],
];

$ch = curl_init("https://api.openai.com/v1/chat/completions");
curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_POST => true,
  CURLOPT_HTTPHEADER => [
    "Authorization: Bearer $OPENAI_API_KEY",
    "Content-Type: application/json",
  ],
  CURLOPT_POSTFIELDS => json_encode($payload),
]);

$response = curl_exec($ch);
$res = json_decode($response, true);
echo json_encode(["response" => $res['choices'][0]['message']['content']]);
?>