<?php
session_start();
if (!isset($_SESSION["admin"])) { http_response_code(403); exit(); }

$new = [
  "username" => $_POST["username"],
  "password" => $_POST["password"]
];
file_put_contents("credentials.json", json_encode($new));
header("Location: dashboard.php");