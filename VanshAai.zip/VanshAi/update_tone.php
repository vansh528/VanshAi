<?php
session_start();
if (!isset($_SESSION["admin"])) { http_response_code(403); exit(); }

$tone = $_POST["tone"];
file_put_contents("settings.json", json_encode(["tone" => $tone]));
header("Location: dashboard.php");