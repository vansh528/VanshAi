<?php
session_start();
if (!isset($_SESSION["admin"])) {
  http_response_code(403);
  exit("403 Forbidden");
}
$settings = json_decode(file_get_contents("settings.json"), true);
?>
<!DOCTYPE html>
<html>
<head><title>Admin Dashboard</title></head>
<body>
  <h2>Admin Panel</h2>
  <form method="POST" action="update_credentials.php">
    <h3>Update Credentials</h3>
    Username: <input name="username"><br>
    Password: <input name="password"><br>
    <button type="submit">Update</button>
  </form>
  <form method="POST" action="update_tone.php">
    <h3>Update Tone</h3>
    Tone: <input name="tone" value="<?= $settings['tone'] ?>"><br>
    <button type="submit">Update</button>
  </form>
  <a href="logout.php">Logout</a>
</body>
</html>