function sendMessage() {
  const input = document.getElementById("user-input").value;
  if (!input.trim()) return;

  const chatBox = document.getElementById("chat-box");
  chatBox.innerHTML += `<div><b>You:</b> ${input}</div>`;

  fetch('chat.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ message: input })
  })
  .then(res => res.json())
  .then(data => {
    chatBox.innerHTML += `<div><b>Muse:</b> ${data.response}</div>`;
    document.getElementById("user-input").value = "";
  });
}